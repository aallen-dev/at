import React, { useState } from 'react'


const App = ({ channel }) => {
    return  <div style={{ overflow: 'auto', width: '100%' }}>
                {channel} sez do do do da da da
            </div>

}
export {App}